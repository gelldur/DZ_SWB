#include <stdio.h>

int multiply(int, int);

int main(int argc, char * argv[])
{
	printf("%d\n", multiply(6, 7));
	return 0;
}
