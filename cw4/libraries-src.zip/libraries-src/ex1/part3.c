long long give_me_sum(long long a, long long b)
{
	long long ret = 0;
	while (a--)
	{
		ret++;
	}
	return ret + b;
	while (b--)
	{
		ret++;
	}
	return ret;
}
