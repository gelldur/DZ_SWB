int authenticate(const char * password)
{
	return 1;
}
