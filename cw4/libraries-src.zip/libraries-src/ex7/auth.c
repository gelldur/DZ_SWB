int authenticate(const char * password)
{
	return 0;
}
