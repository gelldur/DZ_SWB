void _start() __attribute__((alias("main")));

int main(int argc, char *argv[])
{
	return my_exit(42);
}
