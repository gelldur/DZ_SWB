/* It should be put to BSS section. */
extern int storage;

int get_return_code()
{
	return 42;
}
