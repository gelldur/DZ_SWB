#include <stdio.h>

int multiply(int, int);

int main()
{
	printf("%d\n", multiply(4, 5));
	return 0;
}
